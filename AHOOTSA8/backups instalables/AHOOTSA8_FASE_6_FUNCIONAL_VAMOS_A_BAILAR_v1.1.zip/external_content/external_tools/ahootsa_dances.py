"""Ahootsa local dance tools for the activity "Vamos a bailar".

This external tool module exposes three tools to the official Reachy Mini
Conversation App:

- list_ahootsa_dances
- play_ahootsa_dance
- stop_ahootsa_dance

The movement JSON and audio files are loaded from:

    external_content/activities/vamos_a_bailar/

No Hugging Face download is performed during playback.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import threading
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from reachy_mini.motion.recorded_move import RecordedMove
from reachy_mini_conversation_app.tools.core_tools import Tool, ToolDependencies


logger = logging.getLogger(__name__)

TOOLS_DIRECTORY = Path(__file__).resolve().parent
EXTERNAL_CONTENT_DIRECTORY = TOOLS_DIRECTORY.parent
ACTIVITY_DIRECTORY = (
    EXTERNAL_CONTENT_DIRECTORY
    / "activities"
    / "vamos_a_bailar"
)
CATALOG_PATH = ACTIVITY_DIRECTORY / "catalogo_bailes.json"

DANCE_IDS: tuple[str, ...] = (
    "dance1",
    "dance2",
    "dance3",
    "las-ketchup",
    "michael-jackson-thriller",
    "spice-girls",
    "pharrell-williams-happy",
    "queen-we-will-rock-you",
    "the-white-stripes-seven-nation-army",
    "bohemian-rhapsody",
    "happy-birthday",
    "harry-potter",
    "star-wars",
    "the-lion-king",
    "titanic",
    "secret-dance",
)


@dataclass
class _ActiveDance:
    """In-memory state for the current local dance."""

    dance_id: str
    name: str
    started_at: float
    duration_seconds: float
    audio_path: str
    generation: int


_STATE_LOCK = threading.RLock()
_ACTIVE_DANCE: Optional[_ActiveDance] = None
_CLEAR_TIMER: Optional[threading.Timer] = None
_GENERATION = 0


def _normalize(value: object) -> str:
    """Normalize a spoken or written dance name for matching."""
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = text.encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def _load_catalog() -> list[dict[str, Any]]:
    """Load and validate the Phase 5 local dance catalog."""
    if not CATALOG_PATH.is_file():
        raise FileNotFoundError(
            f"No existe el catálogo local de bailes: {CATALOG_PATH}"
        )

    try:
        document = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"El catálogo local no contiene JSON válido: {exc}"
        ) from exc

    moves = document.get("moves")
    if not isinstance(moves, list):
        raise ValueError("El catálogo local no contiene una lista 'moves'.")

    enabled_moves = [
        move
        for move in moves
        if isinstance(move, dict) and bool(move.get("enabled", True))
    ]
    enabled_moves.sort(key=lambda move: int(move.get("order", 9999)))

    found_ids = {
        str(move.get("id", "")).strip()
        for move in enabled_moves
    }
    missing = [dance_id for dance_id in DANCE_IDS if dance_id not in found_ids]
    if missing:
        raise ValueError(
            "Faltan movimientos seleccionados en el catálogo: "
            + ", ".join(missing)
        )

    return enabled_moves


def _catalog_index() -> dict[str, dict[str, Any]]:
    """Return the active catalog indexed by canonical dance ID."""
    return {
        str(move["id"]): move
        for move in _load_catalog()
    }


def _resolve_dance_id(requested: object) -> Optional[str]:
    """Resolve a canonical ID, display name or configured spoken alias."""
    requested_text = str(requested or "").strip()
    if not requested_text:
        return None

    catalog = _load_catalog()
    by_id = {str(move["id"]): move for move in catalog}

    if requested_text in by_id:
        return requested_text

    normalized_requested = _normalize(requested_text)
    for move in catalog:
        candidates = [
            move.get("id", ""),
            move.get("name", ""),
            move.get("short_name", ""),
            *(move.get("aliases") or []),
        ]
        if normalized_requested in {
            _normalize(candidate)
            for candidate in candidates
            if candidate
        }:
            return str(move["id"])

    return None


def _resource_path(move: dict[str, Any], field: str) -> Path:
    """Resolve and validate one resource path declared in the catalog."""
    raw_path = str(move.get(field, "")).strip()
    if not raw_path:
        raise ValueError(
            f"El movimiento {move.get('id')!r} no define {field}."
        )

    path = (ACTIVITY_DIRECTORY / raw_path).resolve()

    # Do not allow a catalog entry to escape the activity directory.
    try:
        path.relative_to(ACTIVITY_DIRECTORY.resolve())
    except ValueError as exc:
        raise ValueError(
            f"Ruta no permitida para {move.get('id')!r}: {path}"
        ) from exc

    if not path.is_file():
        raise FileNotFoundError(
            f"No existe el recurso local de {move.get('id')!r}: {path}"
        )

    return path


def _build_recorded_move(move: dict[str, Any]) -> tuple[RecordedMove, Path]:
    """Construct the official SDK RecordedMove from local JSON and audio."""
    movement_path = _resource_path(move, "local_json")
    audio_path = _resource_path(move, "local_audio")

    try:
        movement_data = json.loads(
            movement_path.read_text(encoding="utf-8")
        )
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Movimiento JSON no válido: {movement_path}: {exc}"
        ) from exc

    recorded_move = RecordedMove(
        movement_data,
        sound_path=audio_path,
    )

    if float(recorded_move.duration) <= 0:
        raise ValueError(
            f"Duración no válida para {move.get('id')!r}."
        )

    return recorded_move, audio_path


def _stop_file_audio(media: Any) -> bool:
    """Stop only the sound-file playbin when possible.

    SDK 1.9.0 exposes `play_sound()` through MediaManager but does not expose a
    matching `stop_sound()` method on that client facade. The LOCAL GStreamer
    backend keeps the file player in `audio._playbin`.

    The private playbin is stopped first so the conversation streaming pipeline
    remains active. A public stop/start fallback is kept for other compatible
    backends.
    """
    audio = getattr(media, "audio", None)
    playbin = getattr(audio, "_playbin", None) if audio is not None else None

    if playbin is not None:
        try:
            from gi.repository import Gst

            playbin.set_state(Gst.State.NULL)
            setattr(audio, "_playbin", None)
            return True
        except Exception:
            logger.exception(
                "Could not stop local sound playbin directly; "
                "using MediaManager fallback"
            )

    # Public fallback. Restart immediately so later assistant audio can play.
    stop_playing = getattr(media, "stop_playing", None)
    start_playing = getattr(media, "start_playing", None)

    if callable(stop_playing):
        stop_playing()
        if callable(start_playing):
            start_playing()
        return True

    return False


def _cancel_clear_timer_locked() -> None:
    """Cancel the state-cleanup timer. Caller must hold _STATE_LOCK."""
    global _CLEAR_TIMER

    if _CLEAR_TIMER is not None:
        _CLEAR_TIMER.cancel()
        _CLEAR_TIMER = None


def _clear_state_if_generation(generation: int) -> None:
    """Clear completed dance state without affecting a newer dance."""
    global _ACTIVE_DANCE, _CLEAR_TIMER

    with _STATE_LOCK:
        if (
            _ACTIVE_DANCE is not None
            and _ACTIVE_DANCE.generation == generation
        ):
            logger.info(
                "Ahootsa local dance completed: dance_id=%s",
                _ACTIVE_DANCE.dance_id,
            )
            _ACTIVE_DANCE = None
            _CLEAR_TIMER = None


def _schedule_state_cleanup_locked(
    duration_seconds: float,
    generation: int,
) -> None:
    """Schedule state cleanup shortly after the movement duration."""
    global _CLEAR_TIMER

    _cancel_clear_timer_locked()

    timer = threading.Timer(
        max(0.1, float(duration_seconds) + 0.5),
        _clear_state_if_generation,
        args=(generation,),
    )
    timer.daemon = True
    _CLEAR_TIMER = timer
    timer.start()


def _stop_active_dance(
    deps: ToolDependencies,
) -> Optional[_ActiveDance]:
    """Stop movement and sound, clear state, and return the previous dance."""
    global _ACTIVE_DANCE, _GENERATION

    with _STATE_LOCK:
        previous = _ACTIVE_DANCE
        _GENERATION += 1
        _cancel_clear_timer_locked()
        _ACTIVE_DANCE = None

        deps.movement_manager.clear_move_queue()

        try:
            _stop_file_audio(deps.reachy_mini.media)
        except Exception:
            logger.exception("Failed to stop Ahootsa dance audio")

        if previous is not None:
            logger.info(
                "Ahootsa local dance stopped: dance_id=%s name=%s",
                previous.dance_id,
                previous.name,
            )
        else:
            logger.info("Ahootsa stop requested with no active local dance")

        return previous


class ListAhootsaDances(Tool):
    """Return the ordered local catalog for the activity."""

    name = "list_ahootsa_dances"
    description = (
        "List the dances available in Ahootsa's local 'Vamos a bailar' "
        "activity. Use this when the user asks what dances or songs are "
        "available. Do not read all results aloud; offer two or three choices."
    )
    needs_response = True
    parameters_schema = {
        "type": "object",
        "properties": {},
        "required": [],
        "additionalProperties": False,
    }

    async def __call__(
        self,
        deps: ToolDependencies,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Return enabled catalog entries in their configured order."""
        del deps, kwargs

        try:
            dances = [
                {
                    "id": str(move["id"]),
                    "name": str(
                        move.get("name")
                        or move.get("short_name")
                        or move["id"]
                    ),
                    "short_name": str(
                        move.get("short_name")
                        or move.get("name")
                        or move["id"]
                    ),
                    "group": str(move.get("group", "")),
                    "aliases": list(move.get("aliases") or []),
                    "order": int(move.get("order", 9999)),
                }
                for move in _load_catalog()
            ]
        except Exception as exc:
            logger.exception("Failed to list Ahootsa dances")
            return {
                "status": "error",
                "error": str(exc),
                "dances": [],
            }

        logger.info(
            "Tool call: list_ahootsa_dances count=%d",
            len(dances),
        )
        return {
            "status": "success",
            "activity": "vamos_a_bailar",
            "count": len(dances),
            "dances": dances,
        }


class PlayAhootsaDance(Tool):
    """Play one selected local movement and its associated audio."""

    name = "play_ahootsa_dance"
    description = (
        "Play one dance from Ahootsa's local catalog. The user must clearly "
        "choose the dance first. Map natural names and aliases to the enum: "
        "Asereje=las-ketchup; Thriller=michael-jackson-thriller; "
        "Happy=pharrell-williams-happy; We Will Rock You="
        "queen-we-will-rock-you; Seven Nation Army="
        "the-white-stripes-seven-nation-army; Cumpleaños feliz="
        "happy-birthday; El rey leon=the-lion-king; Baile secreto="
        "secret-dance. Do not call this automatically or because of inactivity."
    )
    needs_response = False
    parameters_schema = {
        "type": "object",
        "properties": {
            "dance_id": {
                "type": "string",
                "enum": list(DANCE_IDS),
                "description": (
                    "Canonical dance identifier selected by the user."
                ),
            },
        },
        "required": ["dance_id"],
        "additionalProperties": False,
    }

    async def __call__(
        self,
        deps: ToolDependencies,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Start the selected local dance without blocking the conversation."""
        global _ACTIVE_DANCE, _GENERATION

        requested = kwargs.get("dance_id")
        resolved_id = _resolve_dance_id(requested)

        logger.info(
            "Tool call: play_ahootsa_dance requested=%s resolved=%s",
            requested,
            resolved_id,
        )

        if resolved_id is None:
            return {
                "status": "error",
                "error": (
                    f"Baile desconocido: {requested!r}. "
                    f"Disponibles: {list(DANCE_IDS)}"
                ),
            }

        try:
            move = _catalog_index()[resolved_id]
            recorded_move, audio_path = await asyncio.to_thread(
                _build_recorded_move,
                move,
            )
        except Exception as exc:
            logger.exception(
                "Failed to prepare Ahootsa dance: %s",
                resolved_id,
            )
            return {
                "status": "error",
                "dance_id": resolved_id,
                "error": str(exc),
            }

        replaced_previous = False

        with _STATE_LOCK:
            if _ACTIVE_DANCE is not None:
                replaced_previous = True

            # Clear the current primary move and stop only file-based audio.
            deps.movement_manager.clear_move_queue()
            try:
                _stop_file_audio(deps.reachy_mini.media)
            except Exception:
                logger.exception(
                    "Could not stop previous Ahootsa dance audio"
                )

            _GENERATION += 1
            generation = _GENERATION

            deps.movement_manager.queue_move(recorded_move)
            deps.reachy_mini.media.play_sound(str(audio_path))

            active = _ActiveDance(
                dance_id=resolved_id,
                name=str(
                    move.get("name")
                    or move.get("short_name")
                    or resolved_id
                ),
                started_at=time.monotonic(),
                duration_seconds=float(recorded_move.duration),
                audio_path=str(audio_path),
                generation=generation,
            )
            _ACTIVE_DANCE = active
            _schedule_state_cleanup_locked(
                active.duration_seconds,
                generation,
            )

        logger.info(
            "Ahootsa local dance started: dance_id=%s name=%s "
            "duration=%.3f audio=%s replaced_previous=%s",
            active.dance_id,
            active.name,
            active.duration_seconds,
            active.audio_path,
            replaced_previous,
        )

        return {
            "status": "started",
            "activity": "vamos_a_bailar",
            "dance_id": active.dance_id,
            "name": active.name,
            "duration_seconds": round(
                active.duration_seconds,
                3,
            ),
            "audio": True,
            "replaced_previous": replaced_previous,
        }


class StopAhootsaDance(Tool):
    """Stop the current local dance and its audio immediately."""

    name = "stop_ahootsa_dance"
    description = (
        "Immediately stop Ahootsa's current local dance and its music. "
        "Use this without asking for confirmation when the user says para, "
        "basta, detén el baile, stop, or an equivalent request."
    )
    needs_response = True
    parameters_schema = {
        "type": "object",
        "properties": {},
        "required": [],
        "additionalProperties": False,
    }

    async def __call__(
        self,
        deps: ToolDependencies,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Stop movement and audio for the local dance activity."""
        del kwargs

        logger.info("Tool call: stop_ahootsa_dance")
        previous = _stop_active_dance(deps)

        if previous is None:
            return {
                "status": "idle",
                "message": "No había ningún baile local activo.",
            }

        return {
            "status": "stopped",
            "activity": "vamos_a_bailar",
            "previous_dance_id": previous.dance_id,
            "previous_name": previous.name,
        }
