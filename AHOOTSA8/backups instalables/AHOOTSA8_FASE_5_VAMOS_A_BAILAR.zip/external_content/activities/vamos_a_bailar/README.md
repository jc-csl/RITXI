# Actividad `vamos_a_bailar`

Biblioteca local preparada en la **Fase 5** de Ahootsa 8.

Esta carpeta contiene:

```text
actividad.json
catalogo_bailes.json
seleccion_bailes_fase5.csv
preparar_biblioteca_local.py
verificar_biblioteca_local.py
FUENTES_Y_LICENCIAS.md
dataset/data/
```

La preparación copia 16 archivos JSON de movimiento y 16 archivos de audio
desde las descargas realizadas en la Fase 4.

La Fase 5 no añade herramientas al perfil `ahootsa` y no modifica el código
oficial. La conexión con la conversación se realizará en la Fase 6.
